# backend/finances/admin.py
from django.contrib import admin
from .models import DepositProduct

admin.site.register(DepositProduct)